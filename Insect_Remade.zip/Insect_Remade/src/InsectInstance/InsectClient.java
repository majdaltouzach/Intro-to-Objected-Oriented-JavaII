package InsectInstance;

public class InsectClient {
	public static void main(String[] args) {
		System.out.println(Insect.produceRandomFact());
	}
}
